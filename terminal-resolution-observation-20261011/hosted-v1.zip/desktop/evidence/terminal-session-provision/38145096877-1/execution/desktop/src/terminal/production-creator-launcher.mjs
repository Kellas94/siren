import {runProductionCreatorEntry} from './production-creator-entry.mjs';
await runProductionCreatorEntry();
