﻿$ErrorActionPreference = 'Stop'
$started = 'D:\a\siren\siren\desktop\evidence\terminal-resolution-runtime\38145096877-1\qualified-write-output-state\project țară 日本語\started.txt'
$stage = 'D:\a\siren\siren\desktop\evidence\terminal-resolution-runtime\38145096877-1\qualified-write-output-state\project țară 日本語\stage.txt'
$completed = 'D:\a\siren\siren\desktop\evidence\terminal-resolution-runtime\38145096877-1\qualified-write-output-state\project țară 日本語\completed.txt'
[IO.File]::WriteAllText($started, 'fe3d6f927ce12ee77b50fc2bb80d951a')
[IO.File]::WriteAllText($stage, 'entered')
[IO.File]::WriteAllText($stage, 'observation-started')
try {
 $sirenStarted = [DateTime]::UtcNow.Ticks.ToString([Globalization.CultureInfo]::InvariantCulture)
 $sirenEncoding = [Text.UTF8Encoding]::new($true, $true)
 $sirenFinal = 'D:\a\siren\siren\desktop\evidence\terminal-resolution-runtime\38145096877-1\qualified-write-output-state\project țară 日本語\resolution-state.tsv'
 $sirenPending = 'D:\a\siren\siren\desktop\evidence\terminal-resolution-runtime\38145096877-1\qualified-write-output-state\project țară 日本語\resolution-state.tsv.pending'
 $sirenPreference = $ExecutionContext.SessionState.PSVariable.Get('PSModuleAutoLoadingPreference')
 $sirenAutoload = 'unset'
 if ($null -ne $sirenPreference) {
  if ($null -eq $sirenPreference.Value) { $sirenAutoload = 'null' } else {
   $sirenValue = $sirenPreference.Value
   if ($sirenValue.GetType().FullName -ne 'System.String' -and $sirenValue.GetType().FullName -ne 'System.Management.Automation.PSModuleAutoLoadingPreference') { throw 'RESOLUTION_OBSERVATION_INVALID' }
   $sirenPreferenceText = $sirenValue.ToString()
   if ($sirenPreferenceText -cnotin @('All','ModuleQualified','None')) { throw 'RESOLUTION_OBSERVATION_INVALID' }
   $sirenAutoload = 'present:' + $sirenPreferenceText
  }
 }
 $sirenExtension = [Environment]::GetEnvironmentVariable('PATHEXT', [EnvironmentVariableTarget]::Process)
 $sirenExtensionState = 'absent'
 if ($null -ne $sirenExtension) { $sirenExtensionState = 'present:' + $sirenExtension }
 $sirenValues = @{
  token = 'fe3d6f927ce12ee77b50fc2bb80d951a'
  effectiveModulePath = [string]$env:PSModulePath
  PSHOME = [string]$PSHOME
  version = $PSVersionTable.PSVersion.ToString()
  PID = $PID.ToString([Globalization.CultureInfo]::InvariantCulture)
  languageMode = $ExecutionContext.SessionState.LanguageMode.ToString()
  autoloadPreference = $sirenAutoload
  PATH = [string]$env:PATH
  PATHEXT = $sirenExtensionState
  'assembly.System.Management.Automation' = 'absent'
  'assembly.Microsoft.PowerShell.Commands.Utility' = 'absent'
  'assembly.Microsoft.PowerShell.Commands.Management' = 'absent'
  'assembly.Microsoft.PowerShell.ConsoleHost' = 'absent'
  captureStartedUtcTicks = $sirenStarted
 }
 $sirenAssemblyNames = @('System.Management.Automation','Microsoft.PowerShell.Commands.Utility','Microsoft.PowerShell.Commands.Management','Microsoft.PowerShell.ConsoleHost')
 $sirenSeen = @{}
 $sirenAssemblies = [AppDomain]::CurrentDomain.GetAssemblies()
 if ($sirenAssemblies.Length -gt 256) { throw 'RESOLUTION_OBSERVATION_INVALID' }
 foreach ($sirenAssembly in $sirenAssemblies) {
  $sirenAssemblyName = $sirenAssembly.GetName()
  if ($sirenAssemblyNames -ccontains $sirenAssemblyName.Name) {
   if ($sirenSeen.ContainsKey($sirenAssemblyName.Name)) { throw 'RESOLUTION_OBSERVATION_INVALID' }
   $sirenSeen[$sirenAssemblyName.Name] = $true
   $sirenValues['assembly.' + $sirenAssemblyName.Name] = $sirenAssemblyName.Version.ToString()
  }
 }
 $sirenValues['captureEndedUtcTicks'] = [DateTime]::UtcNow.Ticks.ToString([Globalization.CultureInfo]::InvariantCulture)
 $sirenKeys = @('token','effectiveModulePath','PSHOME','version','PID','languageMode','autoloadPreference','PATH','PATHEXT','assembly.System.Management.Automation','assembly.Microsoft.PowerShell.Commands.Utility','assembly.Microsoft.PowerShell.Commands.Management','assembly.Microsoft.PowerShell.ConsoleHost','captureStartedUtcTicks','captureEndedUtcTicks')
 $sirenCaps = @{'token' = 32; 'effectiveModulePath' = 4096; 'PSHOME' = 1024; 'version' = 128; 'PID' = 16; 'languageMode' = 32; 'autoloadPreference' = 64; 'PATH' = 4096; 'PATHEXT' = 1024; 'assembly.System.Management.Automation' = 128; 'assembly.Microsoft.PowerShell.Commands.Utility' = 128; 'assembly.Microsoft.PowerShell.Commands.Management' = 128; 'assembly.Microsoft.PowerShell.ConsoleHost' = 128; 'captureStartedUtcTicks' = 32; 'captureEndedUtcTicks' = 32}
 $sirenBuilder = [Text.StringBuilder]::new()
 [void]$sirenBuilder.Append('SIREN_RESOLUTION_STATE_V1').Append("`r`n")
 foreach ($sirenKey in $sirenKeys) {
  $sirenBytes = $sirenEncoding.GetBytes([string]$sirenValues[$sirenKey])
  if ($sirenBytes.Length -gt $sirenCaps[$sirenKey]) { throw 'RESOLUTION_OBSERVATION_INVALID' }
  [void]$sirenBuilder.Append($sirenKey).Append("`t").Append([Convert]::ToBase64String($sirenBytes)).Append("`r`n")
 }
 $sirenText = $sirenBuilder.ToString()
 if ($sirenEncoding.GetByteCount($sirenText) + $sirenEncoding.GetPreamble().Length -gt 32768) { throw 'RESOLUTION_OBSERVATION_INVALID' }
 [IO.File]::WriteAllText($sirenPending, $sirenText, $sirenEncoding)
 [IO.File]::Move($sirenPending, $sirenFinal)
 [IO.File]::WriteAllText($stage, 'observation-written')
} catch { [IO.File]::WriteAllText($stage, 'observation-invalid'); throw }
[Console]::WriteLine('SIREN_CMDLET_ENTERED_fe3d6f927ce12ee77b50fc2bb80d951a')
[IO.File]::WriteAllText($stage, 'before-write-output')
Microsoft.PowerShell.Utility\Write-Output 'SIREN_PIPELINE_CONTROL'
[IO.File]::WriteAllText($stage, 'after-write-output')
[IO.File]::WriteAllText($completed, 'fe3d6f927ce12ee77b50fc2bb80d951a')
[Console]::WriteLine('SIREN_CMDLET_COMPLETE_fe3d6f927ce12ee77b50fc2bb80d951a')
